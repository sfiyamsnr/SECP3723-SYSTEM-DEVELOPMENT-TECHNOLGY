<?php
session_start();
include('dbconnect.php');

if (!isset($_SESSION['u_sno'])) {
    header("Location: login.php");
    exit();
}

include 'headeradvisor.php';

$course_code = $_GET['course'] ?? '';
$semester = $_GET['sem'] ?? '';

if (!$course_code || !$semester) {
    echo "<p class='text-danger'>Invalid course or semester.</p>";
    exit();
}

$sql = "SELECT u.u_sno, u.u_name FROM tb_registration r
        JOIN tb_user u ON r.r_student = u.u_sno
        WHERE r.r_course = ? AND r.r_sem = ?";

$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, "ss", $course_code, $semester);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$students = mysqli_fetch_all($result, MYSQLI_ASSOC);

mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student List</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background: url('img/bg.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
        }
        .container {
            background: rgba(147, 177, 181, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h2 {
            color: #0B2E33;
            text-align: center;
        }
        .table {
            background: white;
            border-radius: 5px;
            overflow: hidden;
        }
        .table th {
            background: #4F7C82;
            color: white;
            text-align: center;
        }
        .btn-outline-primary {
            border-color: #0B2E33;
            color: #0B2E33;
        }
        .btn-outline-primary:hover {
            background: #0B2E33;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Students Enrolled in <?= htmlspecialchars($course_code) ?> (<?= htmlspecialchars($semester) ?>)</h2>

        <?php if (!empty($students)): ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Student Matric Number</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($students as $student): ?>
                        <tr>
                            <td class="text-center"><?= $no++ ?></td>
                            <td><?= htmlspecialchars($student['u_name']) ?></td>
                            <td class="text-center"> <?= htmlspecialchars($student['u_sno']) ?> </td>
                            <td class="text-center">
                                <a href="student_details.php?student=<?= $student['u_sno'] ?>" class="btn btn-sm btn-outline-primary">Student Details</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text-muted text-center">No students enrolled in this course.</p>
        <?php endif; ?>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>
