<?php include 'headermain.php'; ?>

<style>
    body {
        background-image: linear-gradient(rgba(255, 255, 255, 0.75), rgba(255, 255, 255, 0.25)), url('img/img.jpg');
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        margin: 0;
        padding: 0;
    }

    .login-card {
        background-color: rgba(147, 177, 181, 0.9);
        border-radius: 10px;
        padding: 40px;
        box-shadow: 0 6px 25px rgba(0, 0, 0, 0.2);
        width: 600px;
        max-width: 90%;
    }

    h5 {
        text-align: center;
        color: #0B2E33;
        font-size: 24px;
    }

    .form-label {
        color: #0B2E33;
        font-weight: bold;
    }

    .btn-primary {
        background-color: #4F7C82;
        border: none;
        width: 100%;
        padding: 10px;
        font-size: 18px;
    }

    .btn-primary:hover {
        background-color: #0B2E33;
    }
</style>

<div class="login-card">
    <h5>Please fill to login</h5>
    <form method="POST" action="loginprocess.php">
        <fieldset>
            <div>
                <label for="exampleInputEmail1" class="form-label mt-4">Enter your staff or student number</label>
                <input type="text" name="funame" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your staff or student ID" required>
            </div>

            <div>
                <label for="exampleInputPassword1" class="form-label mt-4">Enter password</label>
                <input type="password" name="fpwd" class="form-control" id="exampleInputPassword1" placeholder="Create password" autocomplete="off" required>
            </div><br>
            
            <p class="mt-3 text-center">
                New user? <a href="register.php" style="color: #0B2E33; font-weight: bold; text-decoration: none;">Create an account</a>.
            </p>
            <button type="submit" class="btn btn-primary">Login</button>
        </fieldset>
    </form>
</div>

<?php include 'footer.php'; ?>
