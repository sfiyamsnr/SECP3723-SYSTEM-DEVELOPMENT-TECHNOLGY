<?php
session_start();
include('dbconnect.php');

if (!isset($_SESSION['u_sno'])) {
    header("Location: login.php");
    exit();
}

include 'headeradvisor.php';

$student_no = $_GET['student'] ?? '';

if (!$student_no) {
    echo "<p class='text-danger'>Invalid student.</p>";
    exit();
}

$sql = "SELECT u.u_sno, u.u_name, u.u_email, u.u_contact FROM tb_user u WHERE u.u_sno = ?";

$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, "s", $student_no);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$student = mysqli_fetch_assoc($result);

mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student List</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background: url('img/bg.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
        }
        .container {
            background: rgba(147, 177, 181, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h2 {
            color: #0B2E33;
            text-align: center;
        }
        .table {
            background: white;
            border-radius: 5px;
            overflow: hidden;
        }
        .table th {
            background: #4F7C82;
            color: white;
            text-align: center;
        }
        .btn-outline-primary {
            border-color: #0B2E33;
            color: #0B2E33;
        }
        .btn-outline-primary:hover {
            background: #0B2E33;
            color: white;
        }
        .btn-back {
            background-color: #0B2E33;
            color: white;
            border-radius: 8px;
            padding: 8px 16px;
            font-size: 16px;
            font-weight: bold;
            transition: 0.3s;
        }
        .btn-back:hover {
            background-color: #4F7C82;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Student Details</h2>

        <?php if ($student): ?>
            <table class="table table-bordered">
                <tr>
                    <th>Student No</th>
                    <td><?= htmlspecialchars($student['u_sno']) ?></td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td><?= htmlspecialchars($student['u_name']) ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?= htmlspecialchars($student['u_email']) ?></td>
                </tr>
                <tr>
                    <th>Contact</th>
                    <td><?= htmlspecialchars($student['u_contact']) ?></td>
                </tr>
            </table>
        <?php else: ?>
            <p class="text-muted text-center">Student not found.</p>
        <?php endif; ?>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>