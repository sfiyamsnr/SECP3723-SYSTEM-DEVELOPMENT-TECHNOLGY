<?php 
include('crssession.php');
if(!session_id()) {
    session_start();
}

include 'headerstudent.php';
include 'dbconnect.php';

$uic = $_SESSION['funame'] ?? '';
$registeredCourses = [];
$selectedSemester = '';
$currentSemester = '2024/2025-2'; 

if (!empty($uic)) {
    $sql = "SELECT r_course, r_sem FROM tb_registration WHERE r_student='$uic' AND r_sem='$currentSemester'";
    $result = mysqli_query($con, $sql);
    while ($row = mysqli_fetch_array($result)) {
        $registeredCourses[$row['r_course']] = $row['r_sem']; 
        $selectedSemester = $row['r_sem']; 
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Course Registration</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body {
           background: url('img/bg.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        .container {
            margin-top: 50px;
        }

        .card {
            background-color: #93B1B5;
            border: none;
            border-radius: 15px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            margin-bottom: 20px;
        }

        .card-header {
            background-color: #4F7C82;
            color: white;
            font-weight: bold;
            text-align: center;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }

        .btn-custom {
            background-color: #0B2E33;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            font-weight: bold;
        }

        .btn-custom:hover {
            background-color: #4F7C82;
        }

        .list-group-item {
            background-color: white;
            border-radius: 10px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="card">
        <div class="card-header">📄 Course Registration Form</div>
        <div class="card-body">
            <div>
                <label for="searchBar" class="form-label">🔍 Search for a Course</label>
                <input type="text" id="searchBar" class="form-control" placeholder="Search by course name or code" onkeyup="filterCourses()">
            </div><br>

            <div>
                <label class="form-label">📌 Available Courses</label>
                <div id="courseList" class="list-group">
                    <?php  
                    $sql = "SELECT * FROM tb_course";
                    $result = mysqli_query($con, $sql);
                    while ($row = mysqli_fetch_array($result)) {
                        $isSelected = array_key_exists($row['c_code'], $registeredCourses);
                        echo "<div class='list-group-item d-flex justify-content-between align-items-center course-item'>";
                        echo "<span class='course-text' data-code='".$row['c_code']."' data-name='".$row['c_name']."'>".$row['c_name']." (".$row['c_code'].")</span>";
                        echo "<button class='btn btn-sm btn-primary' onclick='addCourse(\"".$row['c_code']."\", \"".$row['c_name']."\")' ".($isSelected ? "disabled" : "").">Select</button>";
                        echo "</div>";
                    }
                    ?>
                </div>
            </div><br>

            <div>
                <label class="form-label">✅ Selected Courses</label>
                <ul id="selectedCourses" class="list-group">
                    <?php 
                    if (!empty($registeredCourses)) {
                        foreach ($registeredCourses as $courseCode => $semester) {
                            $query = mysqli_query($con, "SELECT c_name FROM tb_course WHERE c_code='$courseCode'");
                            $courseRow = mysqli_fetch_array($query);
                            $courseName = $courseRow['c_name'] ?? 'Unknown Course';

                            echo "<li class='list-group-item d-flex justify-content-between align-items-center'>";
                            echo "<span>$courseName ($courseCode)</span>";
                            echo "<button class='btn btn-sm btn-danger' onclick='removeCourse(\"$courseCode\")'>Remove</button>";
                            echo "</li>";
                        }
                    }
                    ?>
                </ul>
            </div><br>

<form method="POST" action="courseregisterprocess.php">
    <div>
        <label for="semesterSelect" class="form-label">📆 Select Semester</label>
        <select class="form-select" name="fsem" id="semesterSelect" required>
            <option value="<?php echo $currentSemester; ?>" selected><?php echo $currentSemester; ?></option>
        </select>
    </div><br>

    <input type="hidden" name="fcourse" id="fcourseInput">
    
    <div class="d-flex justify-content-center gap-3">
        <button type="submit" class="btn btn-custom">Register</button>
        <button type="button" class="btn btn-danger" onclick="confirmCancelRegistration()">Cancel Registration</button>
    </div>
</form>

    </div>
</div>

<script>
let selectedCourses = <?php 
    $selectedCoursesArray = [];
    foreach ($registeredCourses as $courseCode => $semester) {
        $query = mysqli_query($con, "SELECT c_name FROM tb_course WHERE c_code='$courseCode'");
        $courseRow = mysqli_fetch_array($query);
        $courseName = $courseRow['c_name'] ?? 'Unknown Course';
        $selectedCoursesArray[] = ["code" => $courseCode, "name" => $courseName];
    }
    echo json_encode($selectedCoursesArray);
?>;

function filterCourses() {
    const searchInput = document.getElementById('searchBar').value.toLowerCase();
    const courseList = document.getElementById('courseList');

    fetch('get_courses.php?search=' + searchInput)
        .then(response => response.json())
        .then(data => {
            courseList.innerHTML = '';
            data.forEach(course => {
                const courseItem = document.createElement('div');
                courseItem.className = 'list-group-item d-flex justify-content-between align-items-center';
                courseItem.innerHTML = `
                    <span>${course.c_name} (${course.c_code})</span>
                    <button class='btn btn-sm btn-primary' onclick='addCourse("${course.c_code}", "${course.c_name}")'>Select</button>
                `;
                courseList.appendChild(courseItem);
            });
        });
}

function addCourse(code, name) {
    if (!selectedCourses.some(course => course.code === code)) {
        selectedCourses.push({ code, name });
        updateSelectedCourses();
    }
}

function removeCourse(courseCode) {
    if (confirm("Are you sure you want to remove this course?")) {
        fetch('removecourse.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'courseCode=' + encodeURIComponent(courseCode)
        })
        .then(response => response.text())
        .then(data => {
            if (data.trim() === 'success') {
                selectedCourses = selectedCourses.filter(course => course.code !== courseCode);
                updateSelectedCourses();
            } else {
                alert('Error removing course. Please try again.');
            }
        })
        .catch(error => console.error('Error:', error));
    }
}


function updateSelectedCourses() {
    const selectedCoursesList = document.getElementById('selectedCourses');
    selectedCoursesList.innerHTML = '';

    selectedCourses.forEach(course => {
        const li = document.createElement('li');
        li.className = 'list-group-item d-flex justify-content-between align-items-center';
        li.innerHTML = `
            <span>${course.name} (${course.code})</span>
            <button class='btn btn-sm btn-danger' onclick='removeCourse("${course.code}")'>Remove</button>
        `;
        selectedCoursesList.appendChild(li);
    });

    document.getElementById('fcourseInput').value = selectedCourses.map(course => course.code).join(',');
}

function confirmCancelRegistration() {
    if (confirm("Are you sure you want to cancel the registration? All selected courses will be removed.")) {
        fetch('cancelregistration.php', {
            method: 'POST'
        })
        .then(response => response.text())
        .then(data => {
            alert('Your current semester registration has been canceled successfully.');
            selectedCourses = [];
            updateSelectedCourses();
            window.location.href = 'courseview.php';
        })
        .catch(error => console.error('Error:', error));
    }
}
</script>
<br><br><br>
<?php include 'footer.php'; ?>
