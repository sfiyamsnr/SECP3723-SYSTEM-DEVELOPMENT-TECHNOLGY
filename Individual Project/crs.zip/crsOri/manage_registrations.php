<?php 
include('crssession.php');
if(!session_id()) {
  session_start();
}
include 'dbconnect.php';
include 'headeradmin.php';

$sql_auto_approve = "UPDATE tb_registration r
    JOIN (
        SELECT r_course, COUNT(*) as enrolled, c.max_student
        FROM tb_registration r
        JOIN tb_course c ON r.r_course = c.c_code
        WHERE r_status = '1'
        GROUP BY r_course
    ) course_count
    ON r.r_course = course_count.r_course
    SET r.r_status = '2'
    WHERE course_count.enrolled < course_count.max_student";
mysqli_query($con, $sql_auto_approve);

$sql_pending = "SELECT * FROM tb_registration
    LEFT JOIN tb_user ON tb_registration.r_student = tb_user.u_sno
    LEFT JOIN tb_course ON tb_registration.r_course = tb_course.c_code
    LEFT JOIN tb_status ON tb_registration.r_status = tb_status.s_id
    WHERE r_status = '1'";
$result_pending = mysqli_query($con, $sql_pending);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Registrations</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body {
           background: url('img/bg.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
        }
        .container {
            background: #FFFFFF;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-top: 30px;
        }
        h3, h5 {
            color: #0B2E33;
            text-align: center;
            font-weight: bold;
        }
        .table thead {
            background-color: #4F7C82;
            color: white;
        }
        .table tbody tr:nth-child(even) {
            background-color: #F0F9FA;
        }
        .btn-approve {
            background-color: #0B2E33;
            color: white;
            font-weight: bold;
            transition: 0.3s;
        }
        .btn-approve:hover {
            background-color: #4F7C82;
        }
        .btn-reject {
            background-color: #D9534F;
            color: white;
            font-weight: bold;
        }
        .btn-reject:hover {
            background-color: #C9302C;
        }
        .btn-cancel {
            background-color: #F0AD4E;
            color: white;
            font-weight: bold;
        }
        .btn-cancel:hover {
            background-color: #EC971F;
        }
        .footer {
            background-color: #0B2E33;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            width: 100%;
            bottom: 0;
            font-weight: bold;
        }
        .bg-primary {
            background-color: #0B2E33 !important;
        }

    </style>

    <script>
        function confirmCancel(registrationId) {
            if (confirm("Are you sure you want to cancel this registration? This action cannot be undone!")) {
                window.location.href = 'registration_process.php?id=' + registrationId + '&action=cancel';
            }
        }
    </script>

</head>
<body>

<div class="container">
    <h3 class="mb-4">Manage Course Registrations</h3>
    
    <h5 class="mb-3">Pending Approvals</h5>
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>Transaction ID</th>
                    <th>Semester</th>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Course</th>
                    <th>Course Name</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_array($result_pending)) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['r_tid']); ?></td>
                        <td><?php echo htmlspecialchars($row['r_sem']); ?></td>
                        <td><?php echo htmlspecialchars($row['u_sno']); ?></td>
                        <td><?php echo htmlspecialchars($row['u_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['r_course']); ?></td>
                        <td><?php echo htmlspecialchars($row['c_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['s_desc']); ?></td>
                        <td>
                            <a href='registration_process.php?id=<?php echo $row['r_tid']; ?>&action=approve' class='btn btn-sm btn-approve'>Approve</a>
                            <a href='registration_process.php?id=<?php echo $row['r_tid']; ?>&action=reject' class='btn btn-sm btn-reject'>Reject</a>
                            <button class="btn btn-sm btn-cancel" onclick="confirmCancel('<?= $row['r_tid']; ?>')">Cancel</button>



                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function confirmCancel(registrationId) {
    console.log("Button clicked for registration: " + registrationId);

    let staffNo = prompt("Please enter your Staff No. to cancel this registration:");

    if (staffNo) {
        console.log("Entered Staff No.: " + staffNo);

        let xhr = new XMLHttpRequest();
        xhr.open("POST", "cancel_action.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                console.log("Response: " + xhr.responseText);
                alert(xhr.responseText);
                window.location.reload();
            }
        };

        xhr.send("staff_no=" + encodeURIComponent(staffNo) + "&registration_id=" + encodeURIComponent(registrationId));
    } else {
        alert("You must enter a valid Staff No.");
    }
}
</script>>

<br><br><br><br>
<?php include 'footer.php'; ?>

</body>
</html>
