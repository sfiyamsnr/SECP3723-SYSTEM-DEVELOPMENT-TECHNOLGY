<?php 
include('crssession.php');
if(!session_id()) {
  session_start();
}

include 'headerstudent.php';
include 'dbconnect.php';

$uic = $_SESSION['funame'];

$current_semesters = '2024/2025-2';
$previous_semester = '2024/2025-1';

$sql_current = "SELECT * FROM tb_registration
                LEFT JOIN tb_course ON tb_registration.r_course = tb_course.c_code
                LEFT JOIN tb_status ON tb_registration.r_status = tb_status.s_id
                WHERE r_student = '$uic' AND r_sem = '$current_semesters' AND r_status != '4'";
$result_current = mysqli_query($con, $sql_current);

$sql_previous = "SELECT * FROM tb_registration
                 LEFT JOIN tb_course ON tb_registration.r_course = tb_course.c_code
                 LEFT JOIN tb_status ON tb_registration.r_status = tb_status.s_id
                 WHERE r_student = '$uic' AND r_sem = '$previous_semester' AND r_status = '4'";
$result_previous = mysqli_query($con, $sql_previous);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Courses</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body {
           background: url('img/bg.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
        }

        .container {
            margin-top: 50px;
        }

        .card {
            background-color: #93B1B5;
            border: none;
            border-radius: 15px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }

        .card-header {
            background-color: #4F7C82; 
            color: white;
            font-weight: bold;
            text-align: center;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }

        .table {
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
        }

        .btn-custom {
            background-color: #0B2E33;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            font-weight: bold;
        }

        .btn-custom:hover {
            background-color: #4F7C82;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="card mb-4">
        <div class="card-header">📚 Current Semester Courses</div>
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Transaction ID</th>
                        <th>Semester</th>
                        <th>Course</th>
                        <th>Course Name</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_array($result_current)) { ?>
                        <tr>
                            <td><?= $row['r_tid'] ?></td>
                            <td><?= $row['r_sem'] ?></td>
                            <td><?= $row['r_course'] ?></td>
                            <td><?= $row['c_name'] ?></td>
                            <td><?= $row['s_desc'] ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <div class="text-center mt-3">
                <a href="courseregister.php" class="btn btn-custom">Modify Course</a>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">📜 Previous Semester Courses (Completed)</div>
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Transaction ID</th>
                        <th>Semester</th>
                        <th>Course</th>
                        <th>Course Name</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_array($result_previous)) { ?>
                        <tr>
                            <td><?= $row['r_tid'] ?></td>
                            <td><?= $row['r_sem'] ?></td>
                            <td><?= $row['r_course'] ?></td>
                            <td><?= $row['c_name'] ?></td>
                            <td><?= $row['s_desc'] ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

</body>
</html>
