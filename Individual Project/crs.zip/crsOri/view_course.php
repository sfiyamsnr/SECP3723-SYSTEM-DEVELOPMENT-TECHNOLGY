<?php
session_start();
include('dbconnect.php');

if (!isset($_SESSION['u_sno'])) {
    header("Location: login.php");
    exit();
}

include 'headeradvisor.php';

$course_code = $_GET['course'] ?? '';

if (!$course_code) {
    echo "<p class='text-danger text-center mt-5'>Invalid course.</p>";
    exit();
}

$sql = "SELECT c.c_code, c.c_name, c.c_credit, c.max_student, u.u_name AS lecturer_name
        FROM tb_course c
        JOIN tb_user u ON c.c_lec = u.u_sno
        WHERE c.c_code = ?";

$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, "s", $course_code);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$course = mysqli_fetch_assoc($result);

mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Details</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body {
            background-color: #B8E3E9;
            color: #0B2E33;
            background-image: linear-gradient(rgba(255, 255, 255, 0.75), rgba(255, 255, 255, 0.25)), url('img/bg.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            background-color: #FFFFFF;
        }
        .card-header {
            background-color: #0B2E33 !important;
            color: white !important;
            font-weight: bold;
            text-align: center;
        }
        .table th {
            background-color: #4F7C82;
            color: white;
        }
        .btn-back {
            background-color: #0B2E33;
            color: white;
            border-radius: 8px;
            padding: 8px 16px;
            font-size: 16px;
            font-weight: bold;
            transition: 0.3s;
        }
        .btn-back:hover {
            background-color: #4F7C82;
        }
        .footer {
            background-color: #0B2E33;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            width: 100%;
            bottom: 0;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <h2 class="mb-4 text-center text-dark">Course Details</h2>

    <?php if ($course): ?>
        <div class="card">
            <div class="card-header">Course Information</div>
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <th>Course Code</th>
                        <td><?= htmlspecialchars($course['c_code']) ?></td>
                    </tr>
                    <tr>
                        <th>Course Name</th>
                        <td><?= htmlspecialchars($course['c_name']) ?></td>
                    </tr>
                    <tr>
                        <th>Credits</th>
                        <td><?= htmlspecialchars($course['c_credit']) ?></td>
                    </tr>
                    <tr>
                        <th>Maximum Students</th>
                        <td><?= htmlspecialchars($course['max_student']) ?></td>
                    </tr>
                    <tr>
                        <th>Lecturer</th>
                        <td><?= htmlspecialchars($course['lecturer_name']) ?></td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="text-center mt-4">
            <a href="assigned_course.php" class="btn btn-back">Back to Courses</a>
        </div>
    <?php else: ?>
        <p class="text-muted text-center">Course not found.</p>
    <?php endif; ?>
</div>

<br><br><br>
<?php include 'footer.php'; ?>

</body>
</html>
