<?php
include('dbconnect.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $courseCode = $_POST['courseCode'] ?? '';
    $uic = $_SESSION['funame'] ?? '';

    if (!empty($courseCode) && !empty($uic)) {
        $sql = "DELETE FROM tb_registration WHERE r_student = '$uic' AND r_course = '$courseCode'";
        if (mysqli_query($con, $sql)) {
            echo "success";
        } else {
            echo "error: " . mysqli_error($con);
        }
    } else {
        echo "error: Missing parameters.";
    }
}
?>
