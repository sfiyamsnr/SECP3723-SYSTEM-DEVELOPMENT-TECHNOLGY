<?php include 'headermain.php'; 
  include 'dbconnect.php';
?>

<style>
  body {
        background: linear-gradient(rgba(255, 255, 255, 0.75), rgba(255, 255, 255, 0.25)),url('img/img.jpg') no-repeat center center fixed;
        background-size: cover;  
  }
  .form-container {
    max-width: 600px;
    background: #93B1B5;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
    margin: 50px auto;
  }
  .form-label {
    font-weight: bold;
    color: #0B2E33;
  }
  .btn-container {
    text-align: center;
  }
  .btn {
    width: 150px;
  }
</style>

<div class="container">
  <div class="form-container">
    <h4 class="text-center mb-4">Registration Form</h4>
    <form method="POST" action="registerprocess.php">
      <div class="mb-3">
        <label class="form-label">Staff or Student Number</label>
        <input type="text" name="funame" class="form-control" placeholder="Enter your ID" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Create Password</label>
        <input type="password" name="fpwd" class="form-control" placeholder="Create password" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Confirm Password</label>
        <input type="password" name="confirmPassword" class="form-control" placeholder="Confirm password" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Email Address</label>
        <input type="email" name="femail" class="form-control" placeholder="Enter email" required>
      </div>
      
      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label">Full Name</label>
          <input type="text" name="fname" class="form-control" placeholder="Enter your full name" required>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">Contact Number</label>
          <input type="text" name="fcontact" class="form-control" placeholder="Your phone number" required>
        </div>
      </div>

      <div class="mb-3">
        <label class="form-label">Date of Birth</label>
        <input type="date" name="fdob" class="form-control" required>
      </div>

      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label">Gender</label>
          <div>
            <input type="radio" name="fgender" value="MALE" required> Male
            <input type="radio" name="fgender" value="FEMALE"> Female
          </div>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">Race</label>
          <select name="frace" class="form-select" required>
            <option value="" disabled selected>Choose Race</option>
            <option value="Malay">Malay</option>
            <option value="Chinese">Chinese</option>
            <option value="Indian">Indian</option>
            <option value="Others">Others</option>
          </select>
        </div>
      </div>
      
      <div class="mb-3">
        <label class="form-label">Religion</label>
        <select name="freligion" class="form-select" required>
          <option value="" disabled selected>Choose Religion</option>
          <option value="Islam">Islam</option>
          <option value="Kristian">Kristian</option>
          <option value="Buddha">Buddha</option>
          <option value="Hindu">Hindu</option>
          <option value="Others">Others</option>
        </select>
      </div>
      
      <div class="mb-3">
        <label class="form-label">Address</label>
        <input type="text" name="faddress" class="form-control" placeholder="Enter home address">
      </div>
      
      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label">City</label>
          <input type="text" name="fcity" class="form-control">
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">Postcode</label>
          <input type="text" name="fpostcode" class="form-control">
        </div>
      </div>
      
      <div class="mb-3">
        <label class="form-label">State</label>
        <select name="fstate" class="form-select" required>
          <option value="" disabled selected>Choose state</option>
          <option value="Johor">Johor</option>
          <option value="Kedah">Kedah</option>
          <option value="Kelantan">Kelantan</option>
          <option value="Melaka">Melaka</option>
          <option value="Negeri Sembilan">Negeri Sembilan</option>
          <option value="Pahang">Pahang</option>
          <option value="Perak">Perak</option>
          <option value="Perlis">Perlis</option>
          <option value="Pulau Pinang">Pulau Pinang</option>
          <option value="Sabah">Sabah</option>
          <option value="Sarawak">Sarawak</option>
          <option value="Selangor">Selangor</option>
          <option value="Terengganu">Terengganu</option>
          <option value="Wilayah Persekutuan">Wilayah Persekutuan Kuala Lumpur</option>
          <option value="Wilayah Persekutuan">Wilayah Persekutuan Labuan</option>
          <option value="Wilayah Persekutuan">Wilayah Persekutuan Putrajaya</option>
        </select>
      </div>

      <div class="btn-container">
        <button type="submit" class="btn btn-primary">Submit</button>
        <button type="reset" class="btn btn-warning">Clear Form</button>
      </div>
    </form>
  </div>
</div>
<br><br>
<?php include 'footer.php'; ?>