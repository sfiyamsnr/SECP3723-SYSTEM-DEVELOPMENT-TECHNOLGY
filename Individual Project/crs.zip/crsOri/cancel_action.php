<?php
include('dbconnect.php');

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $staff_no = mysqli_real_escape_string($con, $_POST['staff_no']);
    $registration_id = mysqli_real_escape_string($con, $_POST['registration_id']);


    $query = "SELECT * FROM tb_user WHERE u_sno = '$staff_no'";
    $result = mysqli_query($con, $query);

    if (mysqli_num_rows($result) > 0) {
        $delete_query = "DELETE FROM tb_registration WHERE r_tid = '$registration_id'";
        if (mysqli_query($con, $delete_query)) {
           echo "Registration ID ($registration_id) has been successfully removed.";

        } else {
            echo "Error: Unable to delete the course.";
        }
    } else {
        echo "Invalid Staff No. Please try again.";
    }

    mysqli_close($con);
}
?>
