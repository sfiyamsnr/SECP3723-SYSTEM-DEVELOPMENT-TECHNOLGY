<?php
include('crssession.php');
if(!session_id())
{
        session_start();
}

include('dbconnect.php');

$funame = $_POST['funame'];
$fpwd = $_POST['fpwd'];
$femail = $_POST['femail'];
$fname = $_POST['fname'];
$fcontact = $_POST['fcontact'];
$fdob = $_POST['fdob'];
$frace = $_POST['frace'];
$freligion = $_POST['freligion'];
$fgender = $_POST['fgender'];
$faddress = $_POST['faddress'];
$fpostcode = $_POST['fpostcode'];
$fstate = $_POST['fstate'];
$fcity = $_POST['fcity'];

$hashed_password = password_hash($fpwd, PASSWORD_DEFAULT);

$sql = "INSERT INTO tb_user (u_sno, u_pwd, u_email, u_name, u_contact, u_req, u_utype, u_dob, u_race, u_religion, u_gender, u_address, u_postcode, u_state, u_city)
        VALUES ('$funame','$hashed_password','$femail','$fname','$fcontact', CURRENT_TIMESTAMP(), '2', '$fdob', '$frace', '$freligion', '$fgender', '$faddress', '$fpostcode', '$fstate', '$fcity')";

if (mysqli_query($con, $sql)) {
    echo "<script>
        alert('Registration successful! Please login.');
        window.location.href = 'login.php';
    </script>";
} else {
    echo "<script>
        alert('Registration failed! Please try again.');
        window.location.href = 'register.php';
    </script>";
}

mysqli_close($con);
?>