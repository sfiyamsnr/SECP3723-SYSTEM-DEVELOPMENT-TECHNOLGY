<?php
include('crssession.php');
if(!session_id()) {
    session_start();
}

include 'headeradmin.php'; 
include 'dbconnect.php';

// Count total courses
$total_courses_query = "SELECT COUNT(*) AS total FROM tb_course";
$total_courses_result = mysqli_query($con, $total_courses_query);
$total_courses = mysqli_fetch_assoc($total_courses_result)['total'];

// Count total students
$total_students_query = "SELECT COUNT(*) AS total FROM tb_user WHERE u_utype = '2'";
$total_students_result = mysqli_query($con, $total_students_query);
$total_students = mysqli_fetch_assoc($total_students_result)['total'];

// Count pending registrations
$pending_reg_query = "SELECT COUNT(*) AS total FROM tb_registration WHERE r_status = '1'";
$pending_reg_result = mysqli_query($con, $pending_reg_query);
$pending_registrations = mysqli_fetch_assoc($pending_reg_result)['total'];

// Count approved registrations
$approved_reg_query = "SELECT COUNT(*) AS total FROM tb_registration WHERE r_status = '2'";
$approved_reg_result = mysqli_query($con, $approved_reg_query);
$approved_registrations = mysqli_fetch_assoc($approved_reg_result)['total'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('img/bg.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
        }
        .dashboard-container {
            margin-top: 50px;
            max-width: 1000px;
            background: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #0B2E33;
            text-align: center;
            font-weight: bold;
        }
        .card {
            border: none;
            border-radius: 10px;
            color: white;
            text-align: center;
        }
        .card .card-text {
            font-size: 20px;
            font-weight: bold;
        }
        .card-total-courses {
            background-color: #4F7C82;
        }
        .card-total-students {
            background-color: #93B1B5;
        }
        .card-pending-registrations {
            background-color: #B8E3E9;
            color: #0B2E33;
        }
        .card-approved-registrations {
            background-color: #0B2E33;
        }
        .btn-view {
            background-color: white;
            color: #0B2E33;
            font-weight: bold;
            padding: 5px 15px;
            border-radius: 5px;
        }
        .btn-view:hover {
            background-color: #93B1B5;
            color: white;
        }
        .bg-primary {
  background-color: #0B2E33 !important;
}
    </style>
</head>
<body>

<div class="container dashboard-container">
    <h2>Admin Dashboard</h2>
    <div class="row mt-4">
        <div class="col-md-6 col-lg-3">
            <div class="card card-total-courses mb-3 p-3">
                <h5 class="card-title">Total Courses</h5>
                <p class="card-text"><?php echo $total_courses; ?></p>
            </div>
        </div>
        <div class="col-md-6 col-lg-3">
            <div class="card card-total-students mb-3 p-3">
                <h5 class="card-title">Total Students</h5>
                <p class="card-text"><?php echo $total_students; ?></p>
            </div>
        </div>
        <div class="col-md-6 col-lg-3">
            <div class="card card-pending-registrations mb-3 p-3">
                <h5 class="card-title">Pending Registrations</h5>
                <p class="card-text"><?php echo $pending_registrations; ?></p>
                <a href="manage_registrations.php" class="btn btn-view">View</a>
            </div>
        </div>
        <div class="col-md-6 col-lg-3">
            <div class="card card-approved-registrations mb-3 p-3">
                <h5 class="card-title">Approved Registrations</h5>
                <p class="card-text"><?php echo $approved_registrations; ?></p>
            </div>
        </div>
    </div>
</div>

</body>
</html>

<?php include 'footer.php'; ?>
