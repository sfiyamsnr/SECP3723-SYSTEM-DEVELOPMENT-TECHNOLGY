<?php
session_start();
include('dbconnect.php');

if (!isset($_SESSION['u_sno'])) {
    header("Location: login.php");
    exit();
}

include 'headeradvisor.php';  
$lecturer_id = $_SESSION['u_sno']; 

$semesters = ["2024/2025-1", "2024/2025-2"];
$assigned_courses = [];

foreach ($semesters as $semester) {
   $sql = "SELECT c.c_code, c.c_name, c.c_credit, c.max_student, 
               COUNT(CASE WHEN r.r_status IN (2, 4) THEN r.r_student END) AS student_count
        FROM tb_course c
        LEFT JOIN tb_registration r 
        ON c.c_code = r.r_course AND r.r_sem = ?
        WHERE c.c_lec = ?
        GROUP BY c.c_code, c.c_name, c.c_credit, c.max_student";

    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, "ss", $semester, $lecturer_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $assigned_courses[$semester] = mysqli_fetch_all($result, MYSQLI_ASSOC);
}

$notif_query = "SELECT * FROM notifications WHERE lecturer_id = '$lecturer_id' AND status = 'unread'";
$result = mysqli_query($con, $notif_query);

$notifications = [];
while ($row = mysqli_fetch_assoc($result)) {
    $notifications[] = $row;
}

$update_query = "UPDATE notifications SET status = 'read' WHERE lecturer_id = '$lecturer_id'";
mysqli_query($con, $update_query);

mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assigned Courses</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body {
            background-color: #B8E3E9;
            color: #0B2E33;
            background-image: linear-gradient(rgba(255, 255, 255, 0.75), rgba(255, 255, 255, 0.25)), url('img/bg.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .card-header {
            background-color: #0B2E33 !important;
            color: white !important;
            font-weight: bold;
        }
        .btn-outline-primary {
            border-color: #0B2E33 !important;
            color: #0B2E33 !important;
        }
        .btn-outline-primary:hover {
            background-color: #0B2E33 !important;
            color: #B8E3E9 !important;
        }
        .footer {
            background-color: #0B2E33;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4 text-center text-primary">Assigned Courses</h2>

        <?php foreach ($semesters as $semester): ?>
            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    Semester: <?= htmlspecialchars($semester) ?>
                </div>
                <div class="card-body">
                    <?php if (!empty($assigned_courses[$semester])): ?>
                        <ul class="list-group">
                            <?php foreach ($assigned_courses[$semester] as $course): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?= htmlspecialchars($course['c_code']) ?> - <?= htmlspecialchars($course['c_name']) ?></strong><br>
                                        Credits: <?= htmlspecialchars($course['c_credit']) ?> | Students Enrolled: <?= htmlspecialchars($course['student_count']) ?> / <?= htmlspecialchars($course['max_student']) ?>
                                    </div>
                                    <div>
                                        <a href="view_students.php?course=<?= urlencode($course['c_code']) ?>&sem=<?= urlencode($semester) ?>" class="btn btn-sm btn-outline-primary">
                                            View Students
                                        </a>
                                        <a href="view_course.php?course=<?= urlencode($course['c_code']) ?>" class="btn btn-sm btn-outline-secondary">
                                            Course Details
                                        </a>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p class="text-muted">No courses assigned for this semester.</p>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
 <script>
    window.onload = function() {
        <?php if (!empty($notifications)): ?>
            let messages = "You have <?= count($notifications); ?> new notification(s):\n\n";
            <?php foreach ($notifications as $notif): ?>
                messages += "- <?= addslashes($notif['message']); ?>\n";
            <?php endforeach; ?>
            alert(messages);
        <?php endif; ?>
    }
</script>
<br><br><br>
<?php include 'footer.php'; ?>
</body>
</html>
