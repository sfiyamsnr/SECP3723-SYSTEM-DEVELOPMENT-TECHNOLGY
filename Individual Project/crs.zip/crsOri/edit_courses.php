<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}
include 'headeradmin.php';
include 'dbconnect.php';

$c_code = $_GET['c_code'];
$sql = "SELECT * FROM tb_course WHERE c_code = '$c_code'";
$result = mysqli_query($con, $sql);
$course = mysqli_fetch_assoc($result);

if (!$course) {
    die("Error: Course not found.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $c_name = $_POST['c_name'];
    $c_credit = $_POST['c_credit'];
    $c_lec = $_POST['c_lec'];
    $max_student = $_POST['max_student'];
    
    if (empty($c_name) || empty($c_credit) || empty($c_lec) || empty($max_student)) {
        echo "<script>alert('All fields are required!');</script>";
    } else {
        $update_sql = "UPDATE tb_course SET c_name='$c_name', c_credit='$c_credit', c_lec='$c_lec', max_student='$max_student' WHERE c_code='$c_code'";
        
        if (mysqli_query($con, $update_sql)) {
            echo "<script>alert('Course updated successfully!'); window.location='manage_courses.php';</script>";
        } else {
            echo "<script>alert('Error updating course: " . mysqli_error($con) . "');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Course</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
             background: url('img/bg.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 600px;
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
        }
                .bg-primary {
  background-color: #0B2E33 !important;
}
        .form-label {
            font-weight: bold;
            color: #0B2E33;
        }
        .btn-primary {
            background-color: #4F7C82;
            border-color: #4F7C82;
        }
        .btn-primary:hover {
            background-color: #0B2E33;
            border-color: #0B2E33;
        }
        .btn-danger {
            background-color: #93B1B5;
            border-color: #93B1B5;
            color: white;
        }
        .btn-danger:hover {
            background-color: #0B2E33;
            border-color: #0B2E33;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4" style="color: #0B2E33;">Edit Course</h2>
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Course Name:</label>
            <input type="text" name="c_name" class="form-control" value="<?php echo htmlspecialchars($course['c_name']); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Credits:</label>
            <input type="number" name="c_credit" class="form-control" value="<?php echo htmlspecialchars($course['c_credit']); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Lecturer:</label>
            <input type="text" name="c_lec" class="form-control" value="<?php echo htmlspecialchars($course['c_lec']); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Max Students:</label>
            <input type="number" name="max_student" class="form-control" value="<?php echo htmlspecialchars($course['max_student']); ?>" required>
        </div>

        <div class="text-center">
            <button type="submit" class="btn btn-primary">Update Course</button>
            <a href="manage_courses.php" class="btn btn-danger">Cancel</a>
        </div>
    </form>
</div>
    <?php include 'footer.php'; ?>
</body>
</html>
