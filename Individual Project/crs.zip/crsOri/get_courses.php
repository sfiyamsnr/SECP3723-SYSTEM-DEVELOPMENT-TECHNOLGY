<?php
include 'dbconnect.php';

$search = $_GET['search'] ?? '';

$sql = "SELECT * FROM tb_course WHERE c_name LIKE '%$search%' OR c_code LIKE '%$search%'";
$result = mysqli_query($con, $sql);

$courses = [];
while ($row = mysqli_fetch_assoc($result)) {
  $courses[] = $row;
}

echo json_encode($courses);
?>
