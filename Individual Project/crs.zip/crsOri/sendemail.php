<?php

function sendEmail($email, $name='user', $subject, $msg){
    
    $mail = new PHPMailer\PHPMailer\PHPMailer();
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'auninawwarah563@gmail.com'; 
    $mail->Password = 'xjizbbhutvbugfjs';  
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    // Email details
    $mail->setFrom('crs@bighit.com', 'University of Moment of Alwaysness');
    $mail->addAddress($email, $name);
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $msg;
    if($mail->send()){
        return 1;
    }else{
        return "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>