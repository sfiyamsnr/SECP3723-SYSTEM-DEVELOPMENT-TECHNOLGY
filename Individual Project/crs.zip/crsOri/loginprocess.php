<?php
session_start();

include('dbconnect.php');

$funame = $_POST['funame'];
$fpwd = $_POST['fpwd'];

$sql = "SELECT * FROM tb_user
        WHERE u_sno=?";

$stmt = mysqli_prepare($con, $sql);

mysqli_stmt_bind_param($stmt, "s", $funame);

mysqli_stmt_execute($stmt);

$result=mysqli_stmt_get_result($stmt); 

$row = mysqli_fetch_array($result);

$count = mysqli_num_rows($result);

if($count == 1) 
{

                if(password_verify($fpwd, $row['u_pwd'])){

       $_SESSION['u_sno'] = $row['u_sno'];;
        $_SESSION['funame'] = $funame;
        $_SESSION['u_email'] = $row['u_email'];
        

        if($row['u_utype'] == 1)
        {
                header('Location: assigned_course.php');
        }     
        if($row['u_utype'] == 2)
        {
                header('Location: courseview.php');
        }  
        if($row['u_utype'] == 3) 
        {
                header('Location: staff.php');
        }                     
}
else 
{
      header('Location: login.php?error=invalid_password');
}
}
else
{
        header('Location: login.php?error=user_not_found'); 
}
mysqli_close($con);

?>
