<?php
//Set DB parameter
$servername = "sql100.infinityfree.com";
$username = "if0_38213793";
$password = "4O9RLfy7WFUTob";
$dbname = "if0_38213793_safiya";

$con = mysqli_connect($servername, $username, $password, $dbname);

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

?>