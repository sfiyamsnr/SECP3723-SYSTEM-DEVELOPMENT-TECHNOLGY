<?php
session_start();
include ('headerstudent.php');
include('dbconnect.php');

if (!isset($_SESSION['u_email'])) {
    header("Location: login.php");
    exit();
}

$femail = $_SESSION['u_email'];

$sql = "SELECT * FROM tb_user WHERE u_email = ?";
$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, "s", $femail);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result && mysqli_num_rows($result) > 0) {
    $tb_user = mysqli_fetch_assoc($result);
} else {
    echo "<script>alert('Error fetching profile data.'); window.location.href='profile.php';</script>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fpwd = $_POST['fpwd'];
    $fconfirmpwd = $_POST['fconfirmpwd'];
    $fcontact = $_POST['fcontact'];
    $faddress = $_POST['faddress'];
    $fpostcode = $_POST['fpostcode'];
    $fstate = $_POST['fstate'];

    // Check if user entered a new password
    if (!empty($fpwd) || !empty($fconfirmpwd)) {
        if ($fpwd !== $fconfirmpwd) {
            echo "<script>alert('Passwords do not match!'); window.history.back();</script>";
            exit();
        }
        $hashedPwd = password_hash($fpwd, PASSWORD_DEFAULT);
        $updateSql = "UPDATE tb_user SET 
                        u_pwd = ?, 
                        u_contact = ?, 
                        u_address = ?, 
                        u_postcode = ?, 
                        u_state = ? 
                      WHERE u_email = ?";
        
        $stmt = mysqli_prepare($con, $updateSql);
        mysqli_stmt_bind_param($stmt, "ssssss", $hashedPwd, $fcontact, $faddress, $fpostcode, $fstate, $femail);
    } else {

        $updateSql = "UPDATE tb_user SET 
                        u_contact = ?, 
                        u_address = ?, 
                        u_postcode = ?, 
                        u_state = ? 
                      WHERE u_email = ?";
        
        $stmt = mysqli_prepare($con, $updateSql);
        mysqli_stmt_bind_param($stmt, "sssss", $fcontact, $faddress, $fpostcode, $fstate, $femail);
    }

    if (mysqli_stmt_execute($stmt)) {
        echo "<script>
                alert('Profile updated successfully!');
                window.location.href='profile.php';
              </script>";
        exit();
    } else {
        echo "<script>alert('Error updating profile.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Profile</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #B8E3E9;
            color: #0B2E33;
            background-image: linear-gradient(rgba(255, 255, 255, 0.75), rgba(255, 255, 255, 0.25)), url('img/bg.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .container {
            background-color: #93B1B5;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 600px;
            margin-top: 50px;
        }
        .form-label {
            font-weight: bold;
        }
        .form-control {
            background-color: #B8E3E9;
            border: 1px solid #4F7C82;
        }
        .btn-success {
            background-color: #4F7C82;
            border-color: #4F7C82;
        }
        .btn-success:hover {
            background-color: #0B2E33;
            border-color: #0B2E33;
        }
        .footer {
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
            background-color: #0B2E33;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
        .navbar-custom {
            background-color: #0B2E33 !important; 
        }
        .navbar-custom .navbar-nav .nav-link {
            color: white !important;
        }
        .navbar-custom .navbar-brand {
            color: white !important;
        }
        .navbar-custom .nav-link:hover {
            color: #B8E3E9 !important; 
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-4">Your Profile</h2>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Matric Number</label>
                <input type="text" class="form-control" name="funame" value="<?= $tb_user['u_sno'] ?>" readonly>
            </div>
            <div class="mb-3">
                <label class="form-label">New Password</label>
                <input type="password" class="form-control" name="fpwd">
            </div>
            <div class="mb-3">
                <label class="form-label">Re-enter New Password</label>
                <input type="password" class="form-control" name="fconfirmpwd">
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="text" class="form-control" name="femail" value="<?= $tb_user['u_email'] ?>" readonly>
            </div>
            <div class="mb-3">
                <label class="form-label">Name</label>
                <input type="text" class="form-control" name="fname" value="<?= $tb_user['u_name'] ?>" readonly>
            </div>
            <div class="mb-3">
                <label class="form-label">Phone Number</label>
                <input type="text" class="form-control" name="fcontact" value="<?= $tb_user['u_contact'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Address</label>
                <input type="text" class="form-control" name="faddress" value="<?= $tb_user['u_address'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Postcode</label>
                <input type="text" class="form-control" name="fpostcode" value="<?= $tb_user['u_postcode'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">State</label>
                <input type="text" class="form-control" name="fstate" value="<?= $tb_user['u_state'] ?>" required>
            </div>
            <button type="submit" class="btn btn-success w-100">Save Changes</button>
        </form>
    </div>
</body>
</html>
<br><br><br><br>
<?php include 'footer.php'; ?>
