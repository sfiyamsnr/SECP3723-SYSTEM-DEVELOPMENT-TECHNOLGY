<?php 
include('crssession.php');
if(!session_id()) {
    session_start();
}

include 'dbconnect.php';

$uic = $_SESSION['funame'] ?? '';
$fcourses = $_POST['fcourse'] ?? ''; 
$fsem = $_POST['fsem'] ?? '';

if (empty($uic) || empty($fsem) || empty($fcourses)) {
    die("<script>alert('Error: Missing required fields.'); window.location.href='courseregister.php';</script>");
}

$fcoursesArray = explode(',', $fcourses);

foreach ($fcoursesArray as $fcourse) {
    
    $check_sql = "SELECT * FROM tb_registration WHERE r_student='$uic' AND r_course='$fcourse' AND r_sem='$fsem'";
    $check_result = mysqli_query($con, $check_sql);

    if (mysqli_num_rows($check_result) == 0) { 
        $count_sql = "SELECT COUNT(*) as enrolled FROM tb_registration WHERE r_course='$fcourse' AND r_status IN (1,2)";
        $count_result = mysqli_query($con, $count_sql);
        $count_row = mysqli_fetch_assoc($count_result);
        $enrolled_students = $count_row['enrolled'] ?? 0;

        $max_sql = "SELECT max_student FROM tb_course WHERE c_code='$fcourse'";
        $max_result = mysqli_query($con, $max_sql);
        $max_row = mysqli_fetch_assoc($max_result);
        $max_students = $max_row['max_student'] ?? 0;

        $status = ($enrolled_students < $max_students) ? '2' : '1'; 

        $sql = "INSERT INTO tb_registration (r_student, r_course, r_sem, r_status) 
                VALUES ('$uic', '$fcourse', '$fsem', '$status')";

        if (!mysqli_query($con, $sql)) {
            die("<script>alert('Error registering courses. Please try again.'); window.location.href='courseregister.php';</script>");
        }
    }
}

mysqli_close($con);
echo "<script>alert('Courses successfully registered!'); window.location.href='courseview.php';</script>";
?>
