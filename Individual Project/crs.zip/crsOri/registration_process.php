<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'headeradmin.php';
include 'dbconnect.php';
require 'vendor/autoload.php';
include 'sendemail.php';

if (!isset($_GET['id']) || !isset($_GET['action'])) {
    die("Invalid request.");
}

$r_tid = mysqli_real_escape_string($con, $_GET['id']);
$action = $_GET['action'];

if ($action === 'approve') {
    $update_sql = "UPDATE tb_registration SET r_status = '2' WHERE r_tid = '$r_tid'";
    $message = "Registration approved successfully!";
} elseif ($action === 'reject') {
    $update_sql = "UPDATE tb_registration SET r_status = '3' WHERE r_tid = '$r_tid'";
    $message = "Registration rejected successfully!";
} elseif ($action === 'cancel') {
    $update_sql = "DELETE FROM tb_registration WHERE r_tid = '$r_tid'";
    $message = "Registration canceled successfully!";
} else {
    die("Invalid action.");
}

// Fetch student email and name
$getEmailQuery = "
    SELECT u.u_email, u.u_name, r.r_course
    FROM tb_user u
    JOIN tb_registration r ON r.r_student = u.u_sno
    WHERE r.r_tid = '$r_tid'";

$emailResult = mysqli_query($con, $getEmailQuery);

if ($emailResult && mysqli_num_rows($emailResult) > 0) {
    $emailRow = mysqli_fetch_assoc($emailResult);
    $studentEmail = trim($emailRow['u_email']);
    $studentName = $emailRow['u_name'];
    $courseCode = $emailRow['r_course'];

    if ($action === 'approve') {
        $emailSubject = "Course Registration Approved!";
        $emailBody = "
            <p>Dear $studentName,</p>
            <p>Your course registration for <b>Course Code: $courseCode</b> has been <b>approved</b>!</p>
            <p>Thank you for registering.</p>
            <p>Best Regards,</p>
            <p>University of Moment of Alwaysness</p>
        ";

        $sendingEmail = sendEmail($studentEmail, $studentName, $emailSubject, $emailBody);

        if ($sendingEmail !== 1) {
            echo "<script>
                alert('Email sending failed: $sendingEmail');
                window.location.href = 'manage_registrations.php';
            </script>";
            exit;
        }
    }
}

if (mysqli_query($con, $update_sql)) {
    echo "<script>alert('$message'); window.location='manage_registrations.php';</script>";
} else {
    echo "<script>alert('Error updating registration: " . mysqli_error($con) . "'); window.location='manage_registrations.php';</script>";
}
?>
