<?php 
include('crssession.php');
if (!session_id()) {
    session_start();
}

include 'dbconnect.php';

$uic = $_SESSION['funame'] ?? '';
$current_semester = '2024/2025-2';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($uic)) {
    $sql = "DELETE FROM tb_registration WHERE r_student='$uic' AND r_sem='$current_semester'";
    if (mysqli_query($con, $sql)) {
        echo "success";
    } else {
        echo "error: " . mysqli_error($con);
    }
} else {
    echo "error: Invalid request.";
}

mysqli_close($con);
?>
