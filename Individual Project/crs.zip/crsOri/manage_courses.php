<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}
include 'headeradmin.php';
include 'dbconnect.php';

$success_message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_course'])) {
    $c_code = $_POST['c_code'];
    $c_name = $_POST['c_name'];
    $c_credit = $_POST['c_credit'];
    $c_lec = $_POST['c_lec'];
    $max_student = $_POST['max_student'];
    
    $sql = "INSERT INTO tb_course (c_code, c_name, c_credit, c_lec, max_student) VALUES ('$c_code', '$c_name', '$c_credit', '$c_lec', '$max_student')";

        if (mysqli_query($con, $sql)) {
                $notif_sql = "INSERT INTO notifications (lecturer_id, message, status) 
                              VALUES ('$c_lec', 'You have been assigned a new course: $c_name ($c_code)', 'unread')";
                mysqli_query($con, $notif_sql);

                $success_message = "Course added successfully, and lecturer notified!";
            } else {
                $success_message = "Error adding course: " . mysqli_error($con);
            }
        }
        
if (isset($_GET['delete'])) {
    $c_code = $_GET['delete'];

    mysqli_query($con, "DELETE FROM tb_registration WHERE r_course='$c_code'");

    if (mysqli_query($con, "DELETE FROM tb_course WHERE c_code='$c_code'")) {
        echo "<script>alert('Course deleted successfully.');</script>";
    } else {
        echo "<script>alert('Error deleting course: " . mysqli_error($con) . "');</script>";
    }

    echo "<script>window.location='manage_courses.php';</script>";
    exit;
}

$courses = mysqli_query($con, "SELECT * FROM tb_course");

if (!$courses) {
    die("Query Failed: " . mysqli_error($con));
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Courses</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.css">
    <style>
        body {
            background: url('img/bg.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
        }
        .container {
            background: rgba(147, 177, 181, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            margin-top: 50px;
        }
        .bg-primary {
            background-color: #0B2E33 !important; 
        }

        h2 {
            color: #0B2E33;
            text-align: center;
            font-weight: bold;
        }
        
        .table-dark {
            background-color: #0B2E33 !important;
            color: white !important;
        }
        .btn-success {
            background: #0B2E33;
            border: none;
        }
        .btn-success:hover {
            background: #4F7C82;
        }
        .btn-sm {
            font-size: 0.85rem;
            padding: 5px 10px;
        }
        .footer {
            background-color: #0B2E33;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
   
    <div class="container mt-4">
        <h2>Manage Courses</h2>
        
        <div class="card p-3 mb-4">
            <form method="POST">
                <div class="row g-2">
                    <div class="col-md-2">
                        <input type="text" name="c_code" class="form-control" placeholder="Course Code" required>
                    </div>
                    <div class="col-md-3">
                        <input type="text" name="c_name" class="form-control" placeholder="Course Name" required>
                    </div>
                    <div class="col-md-2">
                        <input type="number" name="c_credit" class="form-control" placeholder="Credits" required>
                    </div>
                    <div class="col-md-2">
                        <input type="text" name="c_lec" class="form-control" placeholder="Lecturer" required>
                    </div>
                    <div class="col-md-2">
                        <input type="number" name="max_student" class="form-control" placeholder="Max Students" required>
                    </div>
                    <div class="col-md-1 d-grid">
                        <button type="submit" name="add_course" class="btn btn-success">Add</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>Course Code</th>
                        <th>Course Name</th>
                        <th>Credits</th>
                        <th>Lecturer</th>
                        <th>Max Students</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($courses)) : ?>
                        <tr>
                            <td><?= $row['c_code'] ?></td>
                            <td><?= $row['c_name'] ?></td>
                            <td><?= $row['c_credit'] ?></td>
                            <td><?= $row['c_lec'] ?></td>
                            <td><?= $row['max_student'] ?></td>
                            <td>
                                <a href="edit_courses.php?c_code=<?= $row['c_code'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="manage_courses.php?delete=<?= $row['c_code'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this course?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
<br><br><br><br>
    <?php include 'footer.php'; ?>
</body>
</html>